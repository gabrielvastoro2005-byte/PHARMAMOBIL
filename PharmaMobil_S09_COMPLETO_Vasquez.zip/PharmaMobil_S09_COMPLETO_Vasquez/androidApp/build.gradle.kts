import org.jetbrains.kotlin.gradle.dsl.JvmTarget
plugins { alias(libs.plugins.androidApplication); alias(libs.plugins.composeCompiler) }
kotlin { compilerOptions { jvmTarget=JvmTarget.JVM_11 } }
dependencies { implementation(project(":shared")); implementation(libs.androidx.activity.compose); implementation(libs.compose.uiToolingPreview); debugImplementation(libs.compose.uiTooling) }
android {
 namespace="pe.edu.upeu.pharmamobil"; compileSdk=libs.versions.android.compileSdk.get().toInt()
 defaultConfig { applicationId="pe.edu.upeu.pharmamobil"; minSdk=libs.versions.android.minSdk.get().toInt(); targetSdk=libs.versions.android.targetSdk.get().toInt(); versionCode=1; versionName="1.0" }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_11; targetCompatibility=JavaVersion.VERSION_11 }
 buildFeatures { compose=true }
}
