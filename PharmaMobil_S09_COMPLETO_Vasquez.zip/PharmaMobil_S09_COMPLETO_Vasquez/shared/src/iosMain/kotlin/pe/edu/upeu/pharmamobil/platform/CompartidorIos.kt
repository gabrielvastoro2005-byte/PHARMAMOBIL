package pe.edu.upeu.pharmamobil.platform
import platform.UIKit.UIActivityViewController
import platform.UIKit.UIApplication
class CompartidorIos: Compartidor {
 override fun compartirProducto(nombre:String, precio:String){ val texto="Producto: $nombre\nPrecio: $precio"; val vc=UIActivityViewController(listOf(texto), null); val root=UIApplication.sharedApplication.keyWindow?.rootViewController; root?.presentViewController(vc,true,null) }
}
