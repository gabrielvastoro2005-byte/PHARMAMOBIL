package pe.edu.upeu.pharmamobil.di
import org.koin.dsl.module
import pe.edu.upeu.pharmamobil.platform.*
actual val platformModule = module { single<Compartidor> { CompartidorIos() } }
