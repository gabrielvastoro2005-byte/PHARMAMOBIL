package pe.edu.upeu.pharmamobil.di
fun doInitKoin() { initKoin() }
