package pe.edu.upeu.pharmamobil.di

import org.koin.core.KoinApplication
import org.koin.core.context.startKoin
import org.koin.core.module.Module
import org.koin.dsl.module
import pe.edu.upeu.pharmamobil.data.repository.ProductoRepositoryImpl
import pe.edu.upeu.pharmamobil.domain.repository.ProductoRepository
import pe.edu.upeu.pharmamobil.domain.usecase.*

expect val platformModule: Module

val commonModule = module {
    single<ProductoRepository> { ProductoRepositoryImpl() }
    factory { ListarProductosUseCase(get()) }
    factory { BuscarProductosUseCase(get()) }
    factory { GuardarProductoUseCase(get()) }
    factory { ActualizarProductoUseCase(get()) }
    factory { EliminarProductoUseCase(get()) }
}
fun initKoin(extra: KoinApplication.()->Unit = {}) = startKoin {
    extra()
    modules(commonModule, platformModule)
}
