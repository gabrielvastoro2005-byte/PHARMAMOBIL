package pe.edu.upeu.pharmamobil.presentation.producto
import pe.edu.upeu.pharmamobil.domain.model.Producto
import pe.edu.upeu.pharmamobil.platform.formatearSoles

data class ProductoUi(
    val id:Int, val nombre:String, val codigo:String, val laboratorio:String,
    val precio:Double, val stock:Int, val descripcion:String
) {
    val precioFormateado: String get() = formatearSoles(precio)
}
fun Producto.toUi()=ProductoUi(id,nombre,codigo,laboratorio,precio,stock,descripcion)
