package pe.edu.upeu.pharmamobil.domain.repository
import pe.edu.upeu.pharmamobil.domain.model.Producto

interface ProductoRepository {
    fun listar(): List<Producto>
    fun buscar(texto: String): List<Producto>
    fun guardar(producto: Producto): Producto
    fun actualizar(producto: Producto): Producto
    fun eliminar(id: Int): Boolean
}
