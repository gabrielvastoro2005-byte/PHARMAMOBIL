package pe.edu.upeu.pharmamobil.presentation.producto

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.koin.compose.koinInject
import pe.edu.upeu.pharmamobil.domain.model.Producto
import pe.edu.upeu.pharmamobil.domain.usecase.*
import pe.edu.upeu.pharmamobil.platform.Compartidor

@Composable
fun ProductoScreen() {
    val listar: ListarProductosUseCase = koinInject()
    val buscar: BuscarProductosUseCase = koinInject()
    val guardar: GuardarProductoUseCase = koinInject()
    val actualizar: ActualizarProductoUseCase = koinInject()
    val eliminar: EliminarProductoUseCase = koinInject()
    val compartidor: Compartidor = koinInject()

    var query by remember { mutableStateOf("") }
    var version by remember { mutableStateOf(0) }
    var editando by remember { mutableStateOf<Producto?>(null) }
    var mostrarFormulario by remember { mutableStateOf(false) }
    val productos = remember(query,version) { (if(query.isBlank()) listar() else buscar(query)).map { it.toUi() } }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Productos", style=MaterialTheme.typography.headlineMedium)
        Text("CRUD de PharmaMobil", style=MaterialTheme.typography.bodyMedium)
        OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("Buscar por nombre, código o laboratorio")},singleLine=true)
        Button(onClick={editando=null; mostrarFormulario=true}, modifier=Modifier.fillMaxWidth()) { Text("Registrar producto") }

        if(productos.isEmpty()) Text("No se encontraron productos.")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.weight(1f)) {
            items(productos,key={it.id}) { p ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        Text(p.nombre,style=MaterialTheme.typography.titleMedium)
                        Text("${p.codigo} · ${p.laboratorio}")
                        Text(p.precioFormateado,style=MaterialTheme.typography.titleLarge)
                        Text("Stock: ${p.stock}")
                        Text(p.descripcion,style=MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick={compartidor.compartirProducto(p.nombre,p.precioFormateado)}){Text("Compartir")}
                            TextButton(onClick={
                                editando=Producto(p.id,p.nombre,p.codigo,p.laboratorio,p.precio,p.stock,p.descripcion)
                                mostrarFormulario=true
                            }){Text("Editar")}
                            TextButton(onClick={eliminar(p.id); version++}){Text("Eliminar")}
                        }
                    }
                }
            }
        }
    }
    if(mostrarFormulario) ProductoFormDialog(
        inicial=editando,
        onDismiss={mostrarFormulario=false},
        onSave={ p ->
            if(p.id==0) guardar(p) else actualizar(p)
            mostrarFormulario=false; version++
        }
    )
}

@Composable
private fun ProductoFormDialog(inicial:Producto?, onDismiss:()->Unit, onSave:(Producto)->Unit) {
    var nombre by remember(inicial){mutableStateOf(inicial?.nombre?:"")}
    var codigo by remember(inicial){mutableStateOf(inicial?.codigo?:"")}
    var laboratorio by remember(inicial){mutableStateOf(inicial?.laboratorio?:"")}
    var precio by remember(inicial){mutableStateOf(inicial?.precio?.toString()?:"")}
    var stock by remember(inicial){mutableStateOf(inicial?.stock?.toString()?:"")}
    var descripcion by remember(inicial){mutableStateOf(inicial?.descripcion?:"")}
    val valido=nombre.isNotBlank() && codigo.isNotBlank() && precio.toDoubleOrNull()!=null && stock.toIntOrNull()!=null
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text(if(inicial==null)"Nuevo producto" else "Editar producto")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(nombre,{nombre=it},label={Text("Nombre")})
                OutlinedTextField(codigo,{codigo=it},label={Text("Código")})
                OutlinedTextField(laboratorio,{laboratorio=it},label={Text("Laboratorio")})
                OutlinedTextField(precio,{precio=it},label={Text("Precio")})
                OutlinedTextField(stock,{stock=it},label={Text("Stock")})
                OutlinedTextField(descripcion,{descripcion=it},label={Text("Descripción")})
            }
        },
        confirmButton={Button(enabled=valido,onClick={
            onSave(Producto(inicial?.id?:0,nombre,codigo,laboratorio,precio.toDouble(),stock.toInt(),descripcion))
        }){Text("Guardar")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}}
    )
}
