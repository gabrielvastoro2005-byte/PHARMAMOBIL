package pe.edu.upeu.pharmamobil

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import org.koin.compose.KoinContext
import pe.edu.upeu.pharmamobil.presentation.acerca.AcercaScreen
import pe.edu.upeu.pharmamobil.presentation.producto.ProductoScreen

@Composable fun App() = KoinContext {
    var seccion by remember { mutableStateOf(0) }
    MaterialTheme {
        Scaffold(
            topBar={TopAppBar(title={Text("PharmaMobil")})},
            bottomBar={
                NavigationBar {
                    NavigationBarItem(selected=seccion==0,onClick={seccion=0},icon={Text("▦")},label={Text("Productos")})
                    NavigationBarItem(selected=seccion==1,onClick={seccion=1},icon={Text("ⓘ")},label={Text("Acerca de")})
                }
            }
        ){ pad ->
            Surface(Modifier.padding(pad)) {
                when(seccion){ 0->ProductoScreen(); else->AcercaScreen() }
            }
        }
    }
}
