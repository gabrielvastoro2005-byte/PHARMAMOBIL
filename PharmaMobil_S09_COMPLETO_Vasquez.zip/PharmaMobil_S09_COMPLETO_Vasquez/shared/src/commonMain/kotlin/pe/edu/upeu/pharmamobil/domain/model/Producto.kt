package pe.edu.upeu.pharmamobil.domain.model

data class Producto(
    val id: Int,
    val nombre: String,
    val codigo: String,
    val laboratorio: String,
    val precio: Double,
    val stock: Int,
    val descripcion: String
)
