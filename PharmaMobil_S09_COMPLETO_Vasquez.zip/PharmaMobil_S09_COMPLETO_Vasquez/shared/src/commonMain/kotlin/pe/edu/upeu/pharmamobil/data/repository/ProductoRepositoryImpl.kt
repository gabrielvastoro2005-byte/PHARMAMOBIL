package pe.edu.upeu.pharmamobil.data.repository

import pe.edu.upeu.pharmamobil.domain.model.Producto
import pe.edu.upeu.pharmamobil.domain.repository.ProductoRepository

class ProductoRepositoryImpl : ProductoRepository {
    private val productos = mutableListOf(
        Producto(1,"Paracetamol 500 mg","MED-001","Genfar",24.50,45,"Analgésico y antipirético."),
        Producto(2,"Ibuprofeno 400 mg","MED-002","Portugal",18.90,32,"Antiinflamatorio no esteroideo."),
        Producto(3,"Amoxicilina 500 mg","MED-003","AC Farma",35.00,20,"Antibiótico de uso bajo prescripción."),
        Producto(4,"Loratadina 10 mg","MED-004","Medifarma",14.80,51,"Antihistamínico."),
        Producto(5,"Omeprazol 20 mg","MED-005","Genéricos",22.00,38,"Protector gástrico.")
    )
    override fun listar() = productos.toList()
    override fun buscar(texto: String): List<Producto> {
        val q=texto.trim()
        if(q.isBlank()) return listar()
        return productos.filter { it.nombre.contains(q,true) || it.codigo.contains(q,true) || it.laboratorio.contains(q,true) }
    }
    override fun guardar(producto: Producto): Producto {
        val nuevo=producto.copy(id=(productos.maxOfOrNull { it.id } ?: 0)+1)
        productos.add(nuevo); return nuevo
    }
    override fun actualizar(producto: Producto): Producto {
        val i=productos.indexOfFirst { it.id==producto.id }
        require(i>=0) { "Producto no encontrado" }
        productos[i]=producto; return producto
    }
    override fun eliminar(id: Int)=productos.removeAll { it.id==id }
}
