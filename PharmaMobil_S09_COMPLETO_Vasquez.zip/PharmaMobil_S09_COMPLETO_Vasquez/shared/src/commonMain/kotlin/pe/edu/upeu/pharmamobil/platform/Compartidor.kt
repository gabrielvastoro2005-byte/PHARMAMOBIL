package pe.edu.upeu.pharmamobil.platform
interface Compartidor { fun compartirProducto(nombre: String, precio: String) }
