package pe.edu.upeu.pharmamobil.presentation.acerca
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import pe.edu.upeu.pharmamobil.platform.InfoDispositivo

@Composable fun AcercaScreen() {
    val info=InfoDispositivo()
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Acerca de PharmaMobil",style=MaterialTheme.typography.headlineMedium)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Información del dispositivo",style=MaterialTheme.typography.titleLarge)
                Text("Sistema operativo: ${info.sistema}")
                Text("Versión: ${info.version}")
                HorizontalDivider()
                Text("Capacidad nativa N.º 3 implementada con expect/actual.")
                Text("Android: Build.VERSION.RELEASE")
                Text("iOS: UIDevice.currentDevice.systemVersion")
            }
        }
        Text("Sesión 09 · Diferencias por plataforma",style=MaterialTheme.typography.bodyMedium)
    }
}
