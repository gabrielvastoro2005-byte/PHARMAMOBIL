package pe.edu.upeu.pharmamobil.domain.usecase
import pe.edu.upeu.pharmamobil.domain.model.Producto
import pe.edu.upeu.pharmamobil.domain.repository.ProductoRepository

class ListarProductosUseCase(private val repository: ProductoRepository) { operator fun invoke()=repository.listar() }
class BuscarProductosUseCase(private val repository: ProductoRepository) { operator fun invoke(q:String)=repository.buscar(q) }
class GuardarProductoUseCase(private val repository: ProductoRepository) { operator fun invoke(p:Producto)=repository.guardar(p) }
class ActualizarProductoUseCase(private val repository: ProductoRepository) { operator fun invoke(p:Producto)=repository.actualizar(p) }
class EliminarProductoUseCase(private val repository: ProductoRepository) { operator fun invoke(id:Int)=repository.eliminar(id) }
