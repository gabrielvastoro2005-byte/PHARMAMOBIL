package pe.edu.upeu.pharmamobil.di
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module
import pe.edu.upeu.pharmamobil.platform.*
actual val platformModule = module { single<Compartidor> { CompartidorAndroid(androidContext()) } }
