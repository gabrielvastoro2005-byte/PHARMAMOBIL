package pe.edu.upeu.pharmamobil.platform
import android.content.Context
import android.content.Intent
class CompartidorAndroid(private val context: Context): Compartidor {
 override fun compartirProducto(nombre:String, precio:String){ val i=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,"Producto: $nombre\nPrecio: $precio"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }; context.startActivity(Intent.createChooser(i,"Compartir producto").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
