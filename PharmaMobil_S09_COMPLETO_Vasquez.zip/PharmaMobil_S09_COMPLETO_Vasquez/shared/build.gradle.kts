import org.jetbrains.kotlin.gradle.dsl.JvmTarget
plugins { alias(libs.plugins.kotlinMultiplatform); alias(libs.plugins.androidMultiplatformLibrary); alias(libs.plugins.composeMultiplatform); alias(libs.plugins.composeCompiler) }
kotlin {
 listOf(iosArm64(), iosSimulatorArm64()).forEach { it.binaries.framework { baseName="Shared"; isStatic=true } }
 android { namespace="pe.edu.upeu.pharmamobil.shared"; compileSdk=libs.versions.android.compileSdk.get().toInt(); minSdk=libs.versions.android.minSdk.get().toInt(); compilerOptions { jvmTarget=JvmTarget.JVM_11 } }
 sourceSets {
  androidMain.dependencies { api(libs.koin.android); implementation(libs.compose.uiToolingPreview) }
  commonMain.dependencies { api(libs.koin.core); implementation(libs.koin.compose); implementation(libs.compose.runtime); implementation(libs.compose.foundation); implementation(libs.compose.material3); implementation(libs.compose.ui) }
 }
}
